import { useState, useEffect, createContext, useContext, ReactNode } from 'react';

// ============ AUTH CONTEXT ============
interface User {
  id: string;
  email: string;
  name: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  isAuthModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  authMode: 'login' | 'register';
  setAuthMode: (mode: 'login' | 'register') => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  useEffect(() => {
    const savedUser = localStorage.getItem('bloodstrike_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = (email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem('bloodstrike_users') || '[]');
    const foundUser = users.find((u: { email: string; password: string }) => 
      u.email === email && u.password === password
    );
    if (foundUser) {
      const userData = { id: foundUser.id, email: foundUser.email, name: foundUser.name };
      setUser(userData);
      localStorage.setItem('bloodstrike_user', JSON.stringify(userData));
      setAuthModalOpen(false);
      return true;
    }
    return false;
  };

  const register = (name: string, email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem('bloodstrike_users') || '[]');
    if (users.find((u: { email: string }) => u.email === email)) {
      return false;
    }
    const newUser = { id: Date.now().toString(), name, email, password };
    users.push(newUser);
    localStorage.setItem('bloodstrike_users', JSON.stringify(users));
    const userData = { id: newUser.id, email: newUser.email, name: newUser.name };
    setUser(userData);
    localStorage.setItem('bloodstrike_user', JSON.stringify(userData));
    setAuthModalOpen(false);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bloodstrike_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, isAuthModalOpen, setAuthModalOpen, authMode, setAuthMode }}>
      {children}
    </AuthContext.Provider>
  );
}

function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}

// ============ ORDER CONTEXT ============
interface OrderContextType {
  isOrderModalOpen: boolean;
  setOrderModalOpen: (open: boolean) => void;
  selectedService: string;
  setSelectedService: (service: string) => void;
}

const OrderContext = createContext<OrderContextType | null>(null);

function OrderProvider({ children }: { children: ReactNode }) {
  const [isOrderModalOpen, setOrderModalOpen] = useState(false);
  const [selectedService, setSelectedService] = useState('');

  return (
    <OrderContext.Provider value={{ isOrderModalOpen, setOrderModalOpen, selectedService, setSelectedService }}>
      {children}
    </OrderContext.Provider>
  );
}

function useOrder() {
  const context = useContext(OrderContext);
  if (!context) throw new Error('useOrder must be used within OrderProvider');
  return context;
}

// ============ AUTH MODAL ============
function AuthModal() {
  const { isAuthModalOpen, setAuthModalOpen, authMode, setAuthMode, login, register } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (authMode === 'login') {
      const success = login(email, password);
      if (!success) setError('Неверный email или пароль');
    } else {
      if (name.length < 2) {
        setError('Имя должно содержать минимум 2 символа');
        return;
      }
      if (password.length < 6) {
        setError('Пароль должен содержать минимум 6 символов');
        return;
      }
      const success = register(name, email, password);
      if (!success) setError('Пользователь с таким email уже существует');
    }
  };

  const resetForm = () => {
    setName('');
    setEmail('');
    setPassword('');
    setError('');
  };

  useEffect(() => {
    if (!isAuthModalOpen) resetForm();
  }, [isAuthModalOpen]);

  if (!isAuthModalOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setAuthModalOpen(false)}></div>
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 animate-fade-in-up">
        <button 
          onClick={() => setAuthModalOpen(false)}
          className="absolute top-4 right-4 w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors"
        >
          <svg className="w-5 h-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900">
            {authMode === 'login' ? 'Вход в аккаунт' : 'Регистрация'}
          </h2>
          <p className="text-gray-600 mt-2">
            {authMode === 'login' ? 'Войдите, чтобы делать заказы' : 'Создайте аккаунт для заказов'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {authMode === 'register' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Ваше имя</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
                placeholder="Введите имя"
                required
              />
            </div>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
              placeholder="example@mail.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Пароль</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
              placeholder="••••••••"
              required
            />
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 px-4 py-3 rounded-xl text-sm">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white py-3 rounded-xl font-semibold hover:shadow-lg hover:shadow-red-200 transition-all duration-300"
          >
            {authMode === 'login' ? 'Войти' : 'Зарегистрироваться'}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => { setAuthMode(authMode === 'login' ? 'register' : 'login'); setError(''); }}
            className="text-red-500 hover:text-red-600 font-medium transition-colors"
          >
            {authMode === 'login' ? 'Нет аккаунта? Зарегистрируйтесь' : 'Уже есть аккаунт? Войдите'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============ ORDER MODAL ============
function OrderModal() {
  const { isOrderModalOpen, setOrderModalOpen, selectedService, setSelectedService } = useOrder();
  const { user, setAuthModalOpen, setAuthMode } = useAuth();
  
  const [formData, setFormData] = useState({
    service: '',
    package: '',
    currentLevel: '',
    referralLink: '',
    contactMethod: 'telegram',
    contactInfo: '',
    schedule: '',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'payment'>('idle');
  const [orderNumber, setOrderNumber] = useState('');

  const services = [
    { id: 'referral', name: 'Активация рефералов', hasPackages: false },
    { id: 'battlepass', name: 'Прокачка Battle Pass', hasPackages: true },
  ];

  const packages = [
    { id: 'quick', name: 'Быстрый старт', desc: 'Ежедневные и еженедельные миссии' },
    { id: 'full', name: 'Полный цикл (1-50 ур.)', desc: 'С нуля до максимума' },
    { id: 'levels', name: 'Добивка уровней', desc: 'Индивидуальный расчет' },
    { id: 'weapon', name: 'Weapon Mastery + BP', desc: 'BP + прокачка оружия' },
  ];

  useEffect(() => {
    if (selectedService) {
      setFormData(prev => ({ ...prev, service: selectedService }));
    }
  }, [selectedService]);

  useEffect(() => {
    if (!isOrderModalOpen) {
      setFormData({
        service: '',
        package: '',
        currentLevel: '',
        referralLink: '',
        contactMethod: 'telegram',
        contactInfo: '',
        schedule: '',
        notes: ''
      });
      setSubmitStatus('idle');
      setSelectedService('');
      setOrderNumber('');
    }
  }, [isOrderModalOpen, setSelectedService]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      setOrderModalOpen(false);
      setAuthMode('register');
      setAuthModalOpen(true);
      return;
    }

    setIsSubmitting(true);
    
    const selectedServiceName = services.find(s => s.id === formData.service)?.name || formData.service;
    const selectedPackageName = packages.find(p => p.id === formData.package)?.name || formData.package;
    
    const orderDetails = `
НОВЫЙ ЗАКАЗ - BloodStrikeBoost

👤 Информация о клиенте:
- Имя: ${user.name}
- Email: ${user.email}

🎮 Детали заказа:
- Услуга: ${selectedServiceName}
${formData.service === 'battlepass' ? `- Пакет: ${selectedPackageName}` : ''}
${formData.service === 'battlepass' ? `- Текущий уровень BP: ${formData.currentLevel || 'Не указан'}` : ''}
${formData.service === 'referral' ? `- Реферальная ссылка: ${formData.referralLink || 'Будет предоставлена позже'}` : ''}

📱 Контакты:
- Способ связи: ${formData.contactMethod === 'telegram' ? 'Telegram' : 'Discord'}
- Контакт: ${formData.contactInfo}

⏰ Удобное время: ${formData.schedule || 'Не указано'}

📝 Дополнительные примечания:
${formData.notes || 'Нет'}
    `;

    try {
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          access_key: 'a40897e8-dd58-4032-a516-94048b2e7d85',
          to: 'lazarlexstudios@gmail.com',
          subject: `Новый заказ: ${selectedServiceName} - ${user.name}`,
          message: orderDetails,
          from_name: 'BloodStrikeBoost',
        }),
      });

      const newOrderNumber = `BS-${Date.now().toString().slice(-6)}`;
      
      if (response.ok) {
        // Сохраняем заказ локально
        const orders = JSON.parse(localStorage.getItem('bloodstrike_orders') || '[]');
        orders.push({
          id: newOrderNumber,
          userId: user.id,
          ...formData,
          serviceName: selectedServiceName,
          packageName: selectedPackageName,
          createdAt: new Date().toISOString(),
          status: 'pending_payment'
        });
        localStorage.setItem('bloodstrike_orders', JSON.stringify(orders));
        setOrderNumber(newOrderNumber);
        setSubmitStatus('payment');
      } else {
        // Если Web3Forms не настроен, сохраняем локально
        const orders = JSON.parse(localStorage.getItem('bloodstrike_orders') || '[]');
        orders.push({
          id: newOrderNumber,
          userId: user.id,
          ...formData,
          serviceName: selectedServiceName,
          packageName: selectedPackageName,
          createdAt: new Date().toISOString(),
          status: 'pending_payment'
        });
        localStorage.setItem('bloodstrike_orders', JSON.stringify(orders));
        setOrderNumber(newOrderNumber);
        setSubmitStatus('payment');
      }
    } catch {
      // Сохраняем локально при ошибке
      const newOrderNumber = `BS-${Date.now().toString().slice(-6)}`;
      const orders = JSON.parse(localStorage.getItem('bloodstrike_orders') || '[]');
      orders.push({
        id: newOrderNumber,
        userId: user.id,
        ...formData,
        serviceName: services.find(s => s.id === formData.service)?.name,
        packageName: packages.find(p => p.id === formData.package)?.name,
        createdAt: new Date().toISOString(),
        status: 'pending_payment'
      });
      localStorage.setItem('bloodstrike_orders', JSON.stringify(orders));
      setOrderNumber(newOrderNumber);
      setSubmitStatus('payment');
    }
    
    setIsSubmitting(false);
  };

  if (!isOrderModalOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 overflow-y-auto">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOrderModalOpen(false)}></div>
      <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-2xl my-8 animate-fade-in-up">
        <button 
          onClick={() => setOrderModalOpen(false)}
          className="absolute top-4 right-4 w-10 h-10 bg-gray-100 hover:bg-gray-200 rounded-full flex items-center justify-center transition-colors z-10"
        >
          <svg className="w-5 h-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {submitStatus === 'payment' ? (
          <div className="p-12 text-center">
            <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-green-200">
              <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Заказ оформлен!</h2>
            <div className="inline-flex items-center gap-2 bg-gray-100 px-4 py-2 rounded-full mb-6">
              <span className="text-gray-600">Номер заказа:</span>
              <span className="font-bold text-gray-900">{orderNumber}</span>
            </div>
            
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-2xl p-6 mb-8 border border-amber-200">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-orange-500 rounded-xl flex items-center justify-center">
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-bold text-gray-900">Оплата заказа</h3>
              </div>
              <p className="text-gray-700 mb-4">
                Для завершения заказа свяжитесь с исполнителем в Telegram.<br />
                <span className="font-medium">Исполнитель отправит вам реквизиты для оплаты.</span>
              </p>
              <div className="bg-white/70 rounded-xl p-4 mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-gray-600">Услуга:</span>
                  <span className="font-semibold text-gray-900">{services.find(s => s.id === formData.service)?.name}</span>
                </div>
                {formData.package && (
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-gray-600">Пакет:</span>
                    <span className="font-semibold text-gray-900">{packages.find(p => p.id === formData.package)?.name}</span>
                  </div>
                )}
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Контакт:</span>
                  <span className="font-semibold text-gray-900">{formData.contactInfo}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 text-amber-700 text-sm">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Обычно отвечаем в течение 15 минут
              </div>
            </div>

            <a 
              href={`https://t.me/YunjiOfficial?text=${encodeURIComponent(`Привет! Хочу оплатить заказ ${orderNumber}\n\nУслуга: ${services.find(s => s.id === formData.service)?.name}${formData.package ? `\nПакет: ${packages.find(p => p.id === formData.package)?.name}` : ''}\n\nЖду реквизиты для оплаты 🙏`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-3 bg-gradient-to-r from-sky-500 to-blue-600 text-white px-8 py-4 rounded-xl font-semibold hover:shadow-xl hover:shadow-blue-200 transition-all duration-300 hover:-translate-y-1 mb-4"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
              Написать в Telegram для оплаты
            </a>
            
            <div>
              <button
                onClick={() => setOrderModalOpen(false)}
                className="text-gray-500 hover:text-gray-700 font-medium transition-colors"
              >
                Закрыть окно
              </button>
            </div>
          </div>
        ) : (
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Оформление заказа</h2>
              {!user && (
                <p className="text-gray-600 mt-2">Для заказа необходима <button onClick={() => { setOrderModalOpen(false); setAuthMode('register'); setAuthModalOpen(true); }} className="text-red-500 font-medium hover:underline">регистрация</button></p>
              )}
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Выбор услуги */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Выберите услугу *</label>
                <div className="grid grid-cols-2 gap-4">
                  {services.map(service => (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, service: service.id, package: '' }))}
                      className={`p-4 rounded-xl border-2 text-left transition-all ${formData.service === service.id ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-red-200'}`}
                    >
                      <div className="font-semibold text-gray-900">{service.name}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Пакеты для Battle Pass */}
              {formData.service === 'battlepass' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">Выберите пакет *</label>
                  <div className="grid grid-cols-2 gap-3">
                    {packages.map(pkg => (
                      <button
                        key={pkg.id}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, package: pkg.id }))}
                        className={`p-4 rounded-xl border-2 text-left transition-all ${formData.package === pkg.id ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-red-200'}`}
                      >
                        <div className="font-semibold text-gray-900 text-sm">{pkg.name}</div>
                        <div className="text-xs text-gray-500 mt-1">{pkg.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Текущий уровень BP */}
              {formData.service === 'battlepass' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Текущий уровень Battle Pass</label>
                  <input
                    type="number"
                    min="1"
                    max="50"
                    value={formData.currentLevel}
                    onChange={(e) => setFormData(prev => ({ ...prev, currentLevel: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
                    placeholder="Например: 15"
                  />
                </div>
              )}

              {/* Реферальная ссылка */}
              {formData.service === 'referral' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Ваша реферальная ссылка</label>
                  <input
                    type="text"
                    value={formData.referralLink}
                    onChange={(e) => setFormData(prev => ({ ...prev, referralLink: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
                    placeholder="Вставьте ссылку или укажите позже"
                  />
                </div>
              )}

              {/* Способ связи */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Способ связи *</label>
                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, contactMethod: 'telegram' }))}
                    className={`flex-1 p-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${formData.contactMethod === 'telegram' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-red-200'}`}
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
                    </svg>
                    Telegram
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, contactMethod: 'discord' }))}
                    className={`flex-1 p-4 rounded-xl border-2 flex items-center justify-center gap-2 transition-all ${formData.contactMethod === 'discord' ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-red-200'}`}
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
                    </svg>
                    Discord
                  </button>
                </div>
              </div>

              {/* Контактная информация */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {formData.contactMethod === 'telegram' ? 'Telegram (@username)' : 'Discord (user#0000)'} *
                </label>
                <input
                  type="text"
                  value={formData.contactInfo}
                  onChange={(e) => setFormData(prev => ({ ...prev, contactInfo: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
                  placeholder={formData.contactMethod === 'telegram' ? '@username' : 'user#0000'}
                  required
                />
              </div>

              {/* Расписание */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Удобное время (когда вас не будет в игре)</label>
                <input
                  type="text"
                  value={formData.schedule}
                  onChange={(e) => setFormData(prev => ({ ...prev, schedule: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all"
                  placeholder="Например: с 10:00 до 18:00 по МСК"
                />
              </div>

              {/* Примечания */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Дополнительные примечания</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-red-500 focus:border-transparent outline-none transition-all resize-none"
                  rows={3}
                  placeholder="Особые пожелания, вопросы..."
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={!formData.service || !formData.contactInfo || (formData.service === 'battlepass' && !formData.package) || isSubmitting}
                className="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white py-4 rounded-xl font-semibold hover:shadow-lg hover:shadow-red-200 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Отправка...
                  </>
                ) : user ? 'Отправить заказ' : 'Войти и отправить'}
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

// ============ HOOKS ============
function useInView(threshold = 0.1) {
  const [ref, setRef] = useState<HTMLElement | null>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    if (!ref) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
        }
      },
      { threshold }
    );
    observer.observe(ref);
    return () => observer.disconnect();
  }, [ref, threshold]);

  return { ref: setRef, isInView };
}

// ============ HEADER ============
function Header() {
  const [scrolled, setScrolled] = useState(false);
  const { user, setAuthModalOpen, setAuthMode, logout } = useAuth();
  const { setOrderModalOpen } = useOrder();
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-lg' : 'bg-transparent'}`}>
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-200">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
            </svg>
          </div>
          <span className="font-bold text-xl text-gray-900">BloodStrike<span className="text-red-500">Boost</span></span>
        </div>
        <nav className="hidden md:flex items-center gap-8">
          <a href="#services" className="text-gray-600 hover:text-red-500 transition-colors duration-300 font-medium">Услуги</a>
          <a href="#referral" className="text-gray-600 hover:text-red-500 transition-colors duration-300 font-medium">Рефералы</a>
          <a href="#battlepass" className="text-gray-600 hover:text-red-500 transition-colors duration-300 font-medium">Battle Pass</a>
          <a href="#contact" className="text-gray-600 hover:text-red-500 transition-colors duration-300 font-medium">Контакты</a>
        </nav>
        <div className="flex items-center gap-4">
          {user ? (
            <div className="relative">
              <button 
                onClick={() => setUserMenuOpen(!userMenuOpen)}
                className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-full transition-colors"
              >
                <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="font-medium text-gray-700 hidden sm:block">{user.name}</span>
                <svg className="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              {userMenuOpen && (
                <div className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-gray-100 py-2 min-w-[160px]">
                  <div className="px-4 py-2 border-b border-gray-100">
                    <div className="text-sm text-gray-500">Вошли как</div>
                    <div className="font-medium text-gray-900 truncate">{user.email}</div>
                  </div>
                  <button
                    onClick={() => { logout(); setUserMenuOpen(false); }}
                    className="w-full text-left px-4 py-2 text-red-500 hover:bg-red-50 transition-colors"
                  >
                    Выйти
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button 
              onClick={() => { setAuthMode('login'); setAuthModalOpen(true); }}
              className="text-gray-600 hover:text-red-500 transition-colors font-medium"
            >
              Войти
            </button>
          )}
          <button 
            onClick={() => setOrderModalOpen(true)}
            className="bg-gradient-to-r from-red-500 to-red-600 text-white px-6 py-2.5 rounded-full font-semibold hover:shadow-lg hover:shadow-red-200 transition-all duration-300 hover:-translate-y-0.5"
          >
            Заказать
          </button>
        </div>
      </div>
    </header>
  );
}

// ============ HERO ============
function Hero() {
  const { setOrderModalOpen } = useOrder();

  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden bg-gradient-to-b from-gray-50 via-white to-gray-50">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-red-100 rounded-full blur-3xl opacity-50 animate-float"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-100 rounded-full blur-3xl opacity-50 animate-float" style={{ animationDelay: '0.5s' }}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-red-50 to-orange-50 rounded-full blur-3xl opacity-30"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-32 relative z-10">
        <div className="text-center">
          <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm px-4 py-2 rounded-full shadow-md mb-8 animate-fade-in-up" style={{ animationFillMode: 'forwards' }}>
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
            <span className="text-sm text-gray-600 font-medium">Доступен для заказов 24/7</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 animate-fade-in-up" style={{ animationDelay: '0.1s', animationFillMode: 'forwards' }}>
            Профессиональный буст<br />
            <span className="bg-gradient-to-r from-red-500 to-orange-500 bg-clip-text text-transparent">Blood Strike</span>
          </h1>
          
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 animate-fade-in-up" style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}>
            Прокачка Battle Pass, активация рефералов и другие услуги. 
            Быстро, безопасно и с гарантией результата.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up" style={{ animationDelay: '0.3s', animationFillMode: 'forwards' }}>
            <button 
              onClick={() => setOrderModalOpen(true)}
              className="group bg-gradient-to-r from-red-500 to-red-600 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-xl shadow-red-200 hover:shadow-2xl hover:shadow-red-300 transition-all duration-300 hover:-translate-y-1 flex items-center gap-2"
            >
              Заказать сейчас
              <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </button>
            <a href="#services" className="text-gray-700 px-8 py-4 rounded-full font-semibold text-lg border-2 border-gray-200 hover:border-red-300 hover:text-red-500 transition-all duration-300">
              Смотреть услуги
            </a>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 animate-fade-in-up" style={{ animationDelay: '0.4s', animationFillMode: 'forwards' }}>
          {[
            { number: '500+', label: 'Выполненных заказов' },
            { number: '100%', label: 'Гарантия результата' },
            { number: '24/7', label: 'Поддержка клиентов' },
            { number: '5★', label: 'Рейтинг на FunPay' },
          ].map((stat, idx) => (
            <div key={idx} className="text-center p-6 bg-white/70 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="text-3xl md:text-4xl font-bold text-red-500 mb-2">{stat.number}</div>
              <div className="text-gray-600 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
}

// ============ SERVICES SECTION ============
function ServicesSection() {
  const { ref, isInView } = useInView();
  const { setOrderModalOpen, setSelectedService } = useOrder();

  const handleOrderClick = (service: string) => {
    setSelectedService(service);
    setOrderModalOpen(true);
  };

  return (
    <section id="services" ref={ref} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className={`text-center mb-16 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-red-500 font-semibold text-sm uppercase tracking-wider">Наши услуги</span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-3 mb-4">Что мы предлагаем</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Полный спектр услуг для вашего успеха в Blood Strike</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Referral Card */}
          <div className={`group bg-gradient-to-br from-white to-gray-50 p-8 rounded-3xl shadow-xl border border-gray-100 hover:shadow-2xl hover:border-red-100 transition-all duration-500 hover:-translate-y-2 ${isInView ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`} style={{ transitionDelay: '0.2s' }}>
            <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-red-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-red-200">
              <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Активация рефералов</h3>
            <p className="text-gray-600 mb-6">Получите ценные награды через реферальную программу Blood Strike. Золото, скины, ваучеры и многое другое!</p>
            <ul className="space-y-3 mb-8">
              {['Гарантия результата', 'Быстрое выполнение', 'Полная безопасность'].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  {item}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleOrderClick('referral')}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500 to-orange-500 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-red-200 transition-all duration-300 hover:-translate-y-0.5"
            >
              Заказать
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {/* Battle Pass Card */}
          <div className={`group bg-gradient-to-br from-white to-gray-50 p-8 rounded-3xl shadow-xl border border-gray-100 hover:shadow-2xl hover:border-red-100 transition-all duration-500 hover:-translate-y-2 ${isInView ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'}`} style={{ transitionDelay: '0.3s' }}>
            <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-red-200">
              <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Прокачка Battle Pass</h3>
            <p className="text-gray-600 mb-6">Получите все 50 уровней Strike Pass и верните золото. Уникальные скины, эмоции и многое другое!</p>
            <ul className="space-y-3 mb-8">
              {['Возврат 520 золотых', 'Все награды сезона', 'Ручная работа'].map((item, idx) => (
                <li key={idx} className="flex items-center gap-3 text-gray-600">
                  <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  {item}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => handleOrderClick('battlepass')}
              className="inline-flex items-center gap-2 bg-gradient-to-r from-red-500 to-orange-500 text-white px-6 py-3 rounded-full font-semibold hover:shadow-lg hover:shadow-red-200 transition-all duration-300 hover:-translate-y-0.5"
            >
              Заказать
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ REFERRAL SECTION ============
function ReferralSection() {
  const { ref, isInView } = useInView();

  const steps = [
    { num: '01', title: 'Оформление заказа', desc: 'Оплачиваете услугу и предоставляете реферальную ссылку Blood Strike' },
    { num: '02', title: 'Активация', desc: 'Переход по ссылке, регистрация и выполнение всех условий реферальной программы' },
    { num: '03', title: 'Подтверждение', desc: 'Сообщаю о завершении работы, вы проверяете начисление бонуса' },
    { num: '04', title: 'Завершение', desc: 'После успешной проверки подтверждаете выполнение заказа' },
  ];

  return (
    <section id="referral" ref={ref} className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className={`text-center mb-16 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-red-500 font-semibold text-sm uppercase tracking-wider">Рефералы</span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-3 mb-4">Активация реферальной ссылки</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Получите свои награды в Blood Strike! Золото, скины, ваучеры и многое другое!</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-20">
          {steps.map((step, idx) => (
            <div 
              key={idx} 
              className={`relative bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-1 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              style={{ transitionDelay: `${0.1 * idx}s` }}
            >
              <div className="text-5xl font-bold text-red-100 absolute top-4 right-4">{step.num}</div>
              <div className="relative z-10">
                <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-500 rounded-xl flex items-center justify-center text-white font-bold mb-4">
                  {idx + 1}
                </div>
                <h4 className="font-bold text-gray-900 text-lg mb-2">{step.title}</h4>
                <p className="text-gray-600 text-sm">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className={`bg-white rounded-3xl shadow-xl p-8 md:p-12 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '0.5s' }}>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Почему стоит выбрать меня</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: '🎯', title: 'Гарантия результата', desc: 'Выполнение всех условий для начисления наград' },
              { icon: '⚡', title: 'Быстро и эффективно', desc: 'Оперативное выполнение без задержек' },
              { icon: '🛡️', title: 'Безопасность', desc: 'Без доступа к вашему аккаунту' },
              { icon: '🏆', title: 'Опыт', desc: 'Знание всех механик Blood Strike' },
            ].map((item, idx) => (
              <div key={idx} className="text-center group">
                <div className="text-4xl mb-4 group-hover:scale-125 transition-transform duration-300">{item.icon}</div>
                <h4 className="font-bold text-gray-900 mb-2">{item.title}</h4>
                <p className="text-gray-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ BATTLEPASS SECTION ============
function BattlePassSection() {
  const { ref, isInView } = useInView();
  const { setOrderModalOpen, setSelectedService } = useOrder();

  const packages = [
    { name: 'Быстрый старт', desc: 'Выполнение всех текущих ежедневных и еженедельных миссий', time: '1 день', popular: false },
    { name: 'Полный цикл', desc: 'Прокачка пропуска с нуля до максимума (1-50 ур.) + все награды', time: '3-7 дней', popular: true },
    { name: 'Добивка уровней', desc: 'Индивидуальный расчет нужного количества уровней до конца сезона', time: 'Зависит от объема', popular: false },
    { name: 'Weapon Mastery + BP', desc: 'Прокачка BP + поднятие уровня выбранного оружия до 50', time: 'Индивидуально', popular: false },
  ];

  const features = [
    { icon: '🎯', title: 'Миссии на убийства', desc: 'Убийства в голову, из определенного оружия, в конкретных режимах' },
    { icon: '🛡️', title: 'Тактические задачи', desc: 'Использование способностей Страйкеров: дроны, щиты, лечение' },
    { icon: '🎮', title: 'Режимы игры', desc: 'Эффективный фарм в Hot Zone, Squad Fight и Battle Royale' },
    { icon: '🎁', title: 'Сбор наград', desc: 'Все скины, эмоции, сундуки и модули в вашем арсенале' },
  ];

  return (
    <section id="battlepass" ref={ref} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className={`text-center mb-16 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-red-500 font-semibold text-sm uppercase tracking-wider">Strike Pass</span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-3 mb-4">Прокачка Боевого Пропуска</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Получите все 50 уровней и верните 520 золотых слитков! Услуга фактически окупает себя.</p>
        </div>

        <div className={`bg-gradient-to-r from-red-500 to-orange-500 rounded-3xl p-8 md:p-12 text-white mb-16 transition-all duration-700 ${isInView ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`} style={{ transitionDelay: '0.2s' }}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold mb-4">💎 Почему это выгодно?</h3>
              <p className="text-white/90 text-lg">При достижении 50 уровня вы получаете полный возврат стоимости Элитного пропуска — <span className="font-bold">520 золотых слитков</span>. Вы получаете все награды сезона и золото на покупку следующего пропуска!</p>
            </div>
            <div className="flex-shrink-0 text-center">
              <div className="text-6xl font-bold">520</div>
              <div className="text-white/80">золотых слитков</div>
            </div>
          </div>
        </div>

        <div className={`mb-20 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '0.3s' }}>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">📋 Варианты услуг</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {packages.map((pkg, idx) => (
              <div 
                key={idx} 
                onClick={() => { setSelectedService('battlepass'); setOrderModalOpen(true); }}
                className={`relative bg-white rounded-2xl p-6 border-2 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl cursor-pointer ${pkg.popular ? 'border-red-500 shadow-lg shadow-red-100' : 'border-gray-100 hover:border-red-200'}`}
              >
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-red-500 to-orange-500 text-white text-xs font-bold px-4 py-1 rounded-full">
                    ПОПУЛЯРНЫЙ
                  </div>
                )}
                <h4 className="font-bold text-gray-900 text-lg mb-3">{pkg.name}</h4>
                <p className="text-gray-600 text-sm mb-4">{pkg.desc}</p>
                <div className="flex items-center gap-2 text-red-500 font-semibold">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {pkg.time}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className={`transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`} style={{ transitionDelay: '0.4s' }}>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">🚀 Что входит в выполнение</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <div key={idx} className="bg-gray-50 rounded-2xl p-6 hover:bg-white hover:shadow-lg transition-all duration-300">
                <div className="text-3xl mb-4">{feature.icon}</div>
                <h4 className="font-bold text-gray-900 mb-2">{feature.title}</h4>
                <p className="text-gray-600 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ GUARANTEES SECTION ============
function GuaranteesSection() {
  const { ref, isInView } = useInView();

  const guarantees = [
    { icon: '✋', title: 'Ручная работа', desc: 'Никаких ботов или запрещенного софта. Только чистый скилл профессионального игрока.' },
    { icon: '🔒', title: 'Защита аккаунта', desc: 'Используем VPN вашего региона для входа, чтобы избежать подозрений со стороны системы безопасности.' },
    { icon: '📊', title: 'Отчетность', desc: 'По завершении предоставляем скриншоты выполненных заданий и итогового уровня.' },
    { icon: '🤫', title: 'Конфиденциальность', desc: 'Не общаемся с друзьями в игре и не меняем настройки профиля без разрешения.' },
  ];

  return (
    <section className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className={`text-center mb-16 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-red-500 font-semibold text-sm uppercase tracking-wider">Безопасность</span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-3 mb-4">Гарантии и безопасность</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Ваш аккаунт в надежных руках</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {guarantees.map((item, idx) => (
            <div 
              key={idx} 
              className={`bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-2 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
              style={{ transitionDelay: `${0.1 * idx}s` }}
            >
              <div className="text-4xl mb-4">{item.icon}</div>
              <h4 className="font-bold text-gray-900 text-lg mb-3">{item.title}</h4>
              <p className="text-gray-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ============ HOW TO ORDER SECTION ============
function HowToOrderSection() {
  const { ref, isInView } = useInView();
  const { setOrderModalOpen } = useOrder();

  const steps = [
    { num: 1, text: 'Укажите ваш текущий уровень Боевого Пропуска' },
    { num: 2, text: 'Выберите желаемый пакет услуг' },
    { num: 3, text: 'Согласуйте время, когда вы не планируете быть в сети' },
    { num: 4, text: 'Оплатите заказ и ожидайте уведомления о готовности!' },
  ];

  return (
    <section id="contact" ref={ref} className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className={`text-center mb-16 transition-all duration-700 ${isInView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <span className="text-red-500 font-semibold text-sm uppercase tracking-wider">Заказ</span>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mt-3 mb-4">Как сделать заказ?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Всего 4 простых шага до получения ваших наград</p>
        </div>

        <div className="max-w-3xl mx-auto">
          {steps.map((step, idx) => (
            <div 
              key={idx} 
              className={`flex items-center gap-6 mb-6 transition-all duration-500 ${isInView ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'}`}
              style={{ transitionDelay: `${0.1 * idx}s` }}
            >
              <div className="flex-shrink-0 w-14 h-14 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-red-200">
                {step.num}
              </div>
              <div className="bg-gray-50 rounded-2xl p-6 flex-1 hover:bg-white hover:shadow-lg transition-all duration-300">
                <p className="text-gray-800 font-medium">{step.text}</p>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-16 bg-gradient-to-r from-red-500 to-orange-500 rounded-3xl p-12 text-center text-white transition-all duration-700 ${isInView ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`} style={{ transitionDelay: '0.5s' }}>
          <h3 className="text-3xl md:text-4xl font-bold mb-4">Не оставляйте награды врагам!</h3>
          <p className="text-white/90 text-lg mb-8 max-w-2xl mx-auto">Закажите профессиональную прокачку и заберите свой Ultra-скин уже сегодня!</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button 
              onClick={() => setOrderModalOpen(true)}
              className="group bg-white text-red-500 px-8 py-4 rounded-full font-bold text-lg shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 flex items-center gap-2"
            >
              Оформить заказ
              <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </button>
            <a 
              href="https://t.me/YunjiOfficial" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-white/20 backdrop-blur-sm text-white px-8 py-4 rounded-full font-bold text-lg border-2 border-white/30 hover:bg-white/30 transition-all duration-300 hover:-translate-y-1 flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
              Написать в Telegram
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

// ============ FOOTER ============
function Footer() {
  const { setAuthModalOpen, setAuthMode, user } = useAuth();

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
              </svg>
            </div>
            <span className="font-bold text-xl">BloodStrike<span className="text-red-500">Boost</span></span>
          </div>
          <div className="flex items-center gap-6 flex-wrap justify-center">
            <a href="#services" className="text-gray-400 hover:text-white transition-colors">Услуги</a>
            <a href="#referral" className="text-gray-400 hover:text-white transition-colors">Рефералы</a>
            <a href="#battlepass" className="text-gray-400 hover:text-white transition-colors">Battle Pass</a>
            {!user && (
              <button onClick={() => { setAuthMode('register'); setAuthModalOpen(true); }} className="text-gray-400 hover:text-white transition-colors">
                Регистрация
              </button>
            )}
            <a href="https://t.me/YunjiOfficial" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors flex items-center gap-1">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
              </svg>
              Telegram
            </a>
          </div>
          <div className="text-gray-400 text-sm">
            © 2024 BloodStrikeBoost. Все права защищены.
          </div>
        </div>
      </div>
    </footer>
  );
}

// ============ APP ============
export function App() {
  return (
    <AuthProvider>
      <OrderProvider>
        <div className="min-h-screen bg-white">
          <Header />
          <Hero />
          <ServicesSection />
          <ReferralSection />
          <BattlePassSection />
          <GuaranteesSection />
          <HowToOrderSection />
          <Footer />
          <AuthModal />
          <OrderModal />
        </div>
      </OrderProvider>
    </AuthProvider>
  );
}
